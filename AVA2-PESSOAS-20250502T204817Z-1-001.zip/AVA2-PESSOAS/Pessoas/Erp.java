public class Erp extends Pessoas {
    private final String loginErp;
    private final String senhaErp;
    private final String perfilAcessoErp;

public class Erp (
    private final String nomePessoa;
    private final String endereçoPessoa;
    private final String telefonePessoa;
    private final String loginErp;
    private final String senhaErp;
    private final String perfilAcessoErp;
){
    super(nomePessoa, endereçoPessoa, telefonePessoa,)
    this.loginErp = loginErp;
    this.senhaErp = senhaErp;
    this.perfilAcessoErp = perfilAcessoErp;
}
public void manterErp() {
    return manterErp;                              
}
}

    


