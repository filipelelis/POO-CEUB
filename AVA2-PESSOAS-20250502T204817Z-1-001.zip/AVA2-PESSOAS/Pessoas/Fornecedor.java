public class Fornecedor extends Pessoas{
    private final String produtoFornecedor;

public class Fornecedor(
    private final String nomePessoa;
    private final String endereçoPessoa;
    private final String telefonePessoa;
    private final String produtoFornecedor;
){
    super(nomePessoa, endereçoPessoa, telefonePessoa,)
    this.produtoFornecedor = produtoFornecedor;
}
public float listaProdutos() {
    return listaProdutos;     
}
}
