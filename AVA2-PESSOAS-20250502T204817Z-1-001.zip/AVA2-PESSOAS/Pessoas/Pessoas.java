public abstract class Pessoas {
    protected String nomePessoa;
    protected String endereçoPessoa;
    protected String telefonePessoa;

public class Pessoas (String nomePessoa, String endereçoPessoa, String telefonePessoa) {
    this.nomePessoa = nomePessoa;
    this.endereçoPessoa = endereçoPessoa;
    this.telefonePessoa = telefonePessoa;
}
public void manterPessoa(){
    return materPessoa;
}

}
